
public interface MihailKirilov4 {
	void Misho();
}
