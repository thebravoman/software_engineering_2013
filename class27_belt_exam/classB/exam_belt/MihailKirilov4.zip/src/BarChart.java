
public class BarChart extends Chart implements MihailKirilov4 {

	@Override
	public void Misho() {
		this.value2 += value1*2;
	}
	
}
