import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String value;
		ArrayList<Chart> list = new ArrayList<Chart>();
		
		int count = 1;
		
		while(true){
			value = input.nextLine();
			if(value.equals("a")){
				break;
			}
			
			if(count % 2 == 0){
				PieChart newPieChart = new PieChart();
				newPieChart.value1 = Integer.parseInt(value)*2;
				newPieChart.value2 = Integer.parseInt(value)*4;
				list.add(newPieChart);
			}else{
				BarChart newBarChart = new BarChart();
				newBarChart.value1 = Integer.parseInt(value)*3;
				newBarChart.value2 = Integer.parseInt(value)*5;
				list.add(newBarChart);
			}
			count++;
		}
		
		for(Chart c : list){
			System.out.println(c.value1 + " " + c.value2);
		}
		
		for(Chart c : list){
			if(c instanceof BarChart){
				((BarChart) c).Georgi();
			}
		}
		
		for(Chart c : list){
			System.out.println(c.value1 + c.value2);
		}
	}

}
