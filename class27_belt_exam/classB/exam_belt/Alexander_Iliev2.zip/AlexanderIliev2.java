
public interface AlexanderIliev2 {
	void Alexander();
}
