import java.util.ArrayList;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		ArrayList<Chart> list = new ArrayList<Chart>();
        Scanner sc = new Scanner(System.in);
        String[] output;
		while(true){
			output = (sc.nextLine()).split(",");
			if(output.length == 1)
                break;
			if (output[3].equals("b")){
				int one = Integer.parseInt(output[0]);
                int two = Integer.parseInt(output[1]);
                int three = Integer.parseInt(output[2]);
                System.out.println(one + "-" + two + "-" + three);
                BarChart b = new BarChart(one,two,three);
                list.add(b);
			}
			if (output[3].equals("p")){
                int one = Integer.parseInt(output[0]);
                int two = Integer.parseInt(output[1]);
                int three = Integer.parseInt(output[2]);
                System.out.println(one + "-" + two + "-" + three);
                PieChart p = new PieChart(one,two,three);
                list.add(p);
			}
		}
		
		for(Chart c: list){
			if(c instanceof PieChart){
				if(c.getValue2() > c.getValue1()){
					((PieChart) c).Alexander();
                }
            }
		}
		
		for(Chart c: list){
			System.out.print(c.getValue1());
            System.out.print(c.getValue2());
            System.out.println(c.getValue3());
		}
	}
}
