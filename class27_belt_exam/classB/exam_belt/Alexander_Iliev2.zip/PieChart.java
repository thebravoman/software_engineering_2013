
public class PieChart extends Chart implements AlexanderIliev2{

	public PieChart(int value1, int value2, int value3) {
		super(value1, value2, value3);
	}

	@Override
	public void Alexander() {
		this.value2 -= this.value1;
	}
	
}
