
public class BarChart extends Chart{

	public BarChart(int value1, int value2, int value3) {
		super(value1, value2, value3);
	}
	
}
