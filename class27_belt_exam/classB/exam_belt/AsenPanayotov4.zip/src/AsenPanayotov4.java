
public interface AsenPanayotov4 {
	void Asen();
}
