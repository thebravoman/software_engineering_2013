
public class BarChart extends Chart implements AsenPanayotov4 {

	@Override
	public void Asen() {
		this.value2 += value1*2;
	}
	
}
