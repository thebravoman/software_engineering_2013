import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		int counter = 0;
		ArrayList<Chart> list = new ArrayList<Chart>();
		String[] output;
		Scanner input = new Scanner(System.in);

		while (true) {
			output = (input.next()).split(",");

			if (output.length == 1) {
				break;
			}
			if (counter % 2 == 0) {
				int one = Integer.parseInt(output[0]);
				int two = Integer.parseInt(output[1]);
				PieChart p = new PieChart(one, two);
			} else {
				int one = Integer.parseInt(output[0]);
				int two = Integer.parseInt(output[1]);
				BarChart b = new BarChart(one, two);
			}

			counter++;
		}
		
		for(Chart c: list){
			System.out.println();
			System.out.println(c.getValue1());
            System.out.println(c.getValue2());
		}
		for(Chart c: list){
			if (c instanceof PieChart){
				if(c.value2>0){
					  ((PieChart) c).georgi();
				}
				
			}
			
		}
		
	}

}
