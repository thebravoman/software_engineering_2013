
public class PieChart extends Chart implements GeorgiIliev1 {

	
	PieChart(int value1, int value2) {
		super(value1, value2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void georgi() {
		// TODO Auto-generated method stub
		
		value2 *=value1;
	}

	
}
