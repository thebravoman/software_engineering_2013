
public interface GeorgiIliev1 {
	public void georgi();
}