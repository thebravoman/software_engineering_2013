
public interface GeorgiIvanov04 {
	void Georgi();
}
