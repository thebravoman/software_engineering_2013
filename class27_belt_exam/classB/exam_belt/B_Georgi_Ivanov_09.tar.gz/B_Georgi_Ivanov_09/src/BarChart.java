
public class BarChart extends Chart implements GeorgiIvanov04 {

	@Override
	public void Georgi() {
		this.value2 += value1*2;
	}
	
}
