import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String value;
		ArrayList<Chart> list = new ArrayList<Chart>();
		
		int count = 1;
		
		while(true){
			value = input.nextLine();
			if(value.equals("a")){
				break;
			}
			
			if(count % 2 == 0){
				PieChart newPieChart = new PieChart();
				newPieChart.value1 = Integer.parseInt(value)*2;
				newPieChart.value2 = Integer.parseInt(value)*4;
				list.add(newPieChart);
			}else{
				BarChart newBarChart = new BarChart();
				newBarChart.value1 = Integer.parseInt(value)*3;
				newBarChart.value1 = Integer.parseInt(value)*5;
				list.add(newBarChart);
			}
			count++;
		}
		
		for(Chart c : list){
			System.out.println(c.value1 + " " + c.value2);
		}
		
		for(Chart c : list){
			if(c instanceof BarChart){
				((BarChart) c).Georgi();
			}
		}
		
		for(Chart c : list){
			System.out.println(c.value1 + c.value2);
		}
	}

}

//Задача 4 (TaskNumber – 4)
//Дадени са клас PieChart, BarChart всеки с полета: value1, value2.
//Да се изгради общ клас с общите полета.
//От конзолата да се въвеждат едно число- value
//Всяко четно въвеждане създава и съхранява в колекция инстанция на
//PieChart, където value1=value*2 и value2 = value*4,
//Всяко нечетно създава инстанция и съхранява в колекция инстанция на
//BarChart, където value1 = value*3 и value2 = value*5
//BarChart (и само той) имплементира интерфейс
//FirstNameLastNameTaskNumber, където FirstName и LastName са първото
//име и фамилията на ученика реализиращ задачата, TaskNumber е номера на
//задачат. Интерфейсът е с метод стойността на FirstName. Ако ученикът е
//Кирил Митов със задача 1 то класът се казва KirilMitov1, а методът kiril.
//Методът увеличава стойността на value2 със стойността на value1*2.
//В момента, в който от конзолата се въведе буквата „a“, въвеждането и
//създаването на няколко инстанции на Chart от конзолата спира.
//Обхожда се колекцията, в която се съхраняват Chart-овете и се изписват на
//екрана стойностите им value1, value2.
//Извиква се методът firstName на всички PieChart-и.
//10. Обхожда се колекцията, в която се съхраняват Chart-овете и се изписват на
//екрана сумата от стойностите им за полетата value1, value2.
