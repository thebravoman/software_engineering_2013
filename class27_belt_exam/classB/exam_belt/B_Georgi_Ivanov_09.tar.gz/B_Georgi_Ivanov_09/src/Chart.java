
public class Chart {
	protected int value1;
	protected int value2;
}
