package GreenBelt;

public class BarChart extends Chart {

	BarChart(int value1, int value2) {
		super(value1, value2);
		// TODO Auto-generated constructor stub
	}

	
}
