package GreenBelt;

public interface GeorgiKabadzhov1 {
	public void Goshko();
}
