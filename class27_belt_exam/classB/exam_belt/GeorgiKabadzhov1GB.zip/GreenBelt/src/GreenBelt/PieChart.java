package GreenBelt;

public class PieChart extends Chart implements GeorgiKabadzhov1 {

	PieChart(int value1, int value2) {
		super(value1, value2);
		// TODO Auto-generated constructor stub
	}
	
	
	public void Goshko() {
        this.setValue2(this.getValue2() * this.getValue1());
	}
}
